AXIOM — Daily Further Maths

START IN 30 SECONDS
1. Open index.html in a browser. No accounts or installs needed.
2. To put the website online, create a public GitHub repository and upload index.html and service-worker.js to its root.
3. In GitHub > Settings > Pages, select Deploy from a branch, main, / (root), then Save.
4. Open the Pages URL after GitHub publishes it. Add it to your phone's home screen if desired.

WHAT'S INCLUDED
- Daily mixed-topic practice: 5, 7 or 10 questions, selectable in Settings
- Mistake feedback with worked steps and a fresh version of the same question type
- Random practice restricted to lessons taught so far
- Topic Explorer that permits practising all topics, including future lessons
- Revision notes and worked examples for all topics
- Question bookmarks, mastery tracking, due reviews, XP, streaks, mistakes
- Browser-local progress, JSON export/import, light offline caching when hosted

IMPORTANT
- The learning schedule is taken from the uploaded 2026-27 Year 1 AQA AMSP scheme of work. Unlocking uses lesson dates (not deadlines).
- The question variants are generated offline from manually authored templates. They are original practice prompts, not verbatim AQA past-paper questions.
- Answers are checked by local mathematical logic, not by an AI tutor. Most responses are numbers, fractions, ordered lists of values or multiple-choice selections. It does not grade free-form algebraic proofs.
- Data is stored in this browser, not synchronised between devices. Export a backup before switching devices or clearing browser data.
- This is an independent revision companion, not an official AQA or AMSP product.
